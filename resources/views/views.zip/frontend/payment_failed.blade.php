@extends('frontend.layout.layout')
@section('content')
    failed
@endsection