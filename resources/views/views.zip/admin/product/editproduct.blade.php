<?php $page="editproduct";?>
@extends('layout.mainlayout')
@section('content')	
<div class="page-wrapper">
    <div class="content">
        @component('components.pageheader')                
			@slot('title') Product Edit @endslot
			@slot('title_1') Update your product @endslot
		@endcomponent
        <!-- /add -->
        <form action="{{route('admin.product.update',[$product->id])}}" method="post" class="submit-form" enctype="multipart/form-data">
            @csrf
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-3 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Product Name</label>
                                <input type="text" name="name" value="{{$product->name}}">
                                <div class="text-danger form-error" id="name_error"></div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Print Name</label>
                                <input type="text" name="display_name" value="{{$product->display_name}}">
                                <div class="text-danger form-error" id="display_name_error"></div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6 col-12">
                            <div class="form-group">
                                <label>HSN No.</label>
                                <input type="text" name="hsn_code" value="{{$product->hsn_code}}">
                                <div class="text-danger form-error" id="hsn_code_error"></div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Category</label>
                                <select class="select filter-category" name="category">
                                    <option value="">Choose Category</option>
                                    @foreach ($categories as $category)
                                    <option value="{{$category->id}}" {{$product->category_id == $category->id ? 'selected' : ''}}>{{$category->name}}</option>
                                    @endforeach
                                </select>
                                <div class="text-danger form-error" id="category_error"></div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Sub Category</label>
                                <select class="select sub-category-list" name="subcategory">
                                    <option value="">Choose Sub Category</option>
                                    
                                    @foreach ($product->category->childCategory as $category)
                                    <option value="{{$category->id}}" {{$product->subcategory_id == $category->id ? 'selected' : ''}}>{{$category->name}}</option>
                                    @endforeach
                                </select>
                                <div class="text-danger form-error" id="subcategory_error"></div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Brand</label>
                                <select class="select filter-brand" name="brand">
                                    <option value="">Choose Brand</option>
                                    @foreach ($brands as $brand)
                                    <option value="{{$brand->id}}" {{$product->brand_id == $brand->id ? 'selected' : ''}}>{{$brand->name}}</option>
                                    @endforeach
                                </select>
                                <div class="text-danger form-error" id="brand_error"></div>
                            </div>
                        </div>

                     
                        <div class="col-lg-3 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Sub Brand</label>
                                <select class="select filter-sub-brand" name="sub_brand">
                                    <option value="">Choose Sub Brand</option>
                                    @foreach ($product->brand->childs as $brand)
                                    <option value="{{$brand->id}}" {{$product->sub_brand_id == $brand->id ? 'selected' : ''}}>{{$brand->name}}</option>
                                        
                                    @endforeach
                                </select>
                                <div class="text-danger form-error" id="sub_brand_error"></div>
                            </div>
                        </div>


                        
                              
                        <div class="col-lg-3 col-sm-6 col-12">
                            <div class="form-group">
                                <label>	Status</label>
                                <select class="select" name="status">
                                    @foreach (statusList() as $key => $status)
                                        
                                    <option value="{{$key}}" {{$product->status == $key ? 'selected' : ''}}>{{$status}}</option>
                                    @endforeach

                                </select>
                            </div>
                        </div>
                       
                        <div class="col-lg-2 col-sm-6 col-12">
                            <div class="form-group">
                                <label>	Purchase Tax</label>
                                <select class="select" name="purchase_tax">
                                    <option value="">Select Tax</option>
                                    @foreach(purchaseTax() as $tax)
                                    <option value="{{$tax['value']}}" {{$product->purchase_tax == $tax['value'] ? 'selected' : ''}}>{{$tax['name']}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                         <div class="col-lg-2 col-sm-6 col-12">
                            <div class="form-group">
                                <label>	Sale Tax</label>
                                <select class="select" name="sale_tax">
                                    <option value="">Select Tax</option>
                                    @foreach(saleTax() as $tax)
                                    <option value="{{$tax['value']}}" {{$product->sale_tax == $tax['value'] ? 'selected' : ''}}>{{$tax['name']}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                       
                      
                        <div class="col-lg-3 col-sm-6 col-12">
                            <div class="form-group">
                                <label>Expiry Months </label>
                                <input type="numeric" name="expiry_months" class="form-control" value="{{$product->expiry_months}}">
                                <div class="text-danger form-error" id="expiry_months_error"></div>
                            </div>
                        </div>
                        {{-- <div class="col-md-3">
                            <div class="form-group">
                                <label><input type="checkbox" name="purchase_tax_include">	Purchase Tax Including</label>
                                <label><input type="checkbox" name="sale_tax_include">	Sale Tax Including</label>

                            </div>
                        </div> --}}
                        
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Description</label>
                                <textarea class="form-control" name="description">{{$product->description}}</textarea>
                                <div class="text-danger form-error" id="description_error"></div>
                            </div>
                        </div>

                       
                 
                       
                       
                    </div>
                </div>
            </div>
            @if($product->product_type == 'simple')
            <div class="card" id="simple-product-section">
                <div class="card-header">
                    <h4>Price Details</h4>
                </div>
                <div class="card-body">
                  
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>SKU</label>
                                    <input type="text" name="sku" value="{{$product->varaint->sku ?? ''}}">
                                    <div class="text-danger form-error" id="sku_error"></div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Minimum Qty</label>
                                    <input type="text" name="minimum_quantity"  value="{{$product->varaint->minimum_quantity ?? ''}}">
                                    <div class="text-danger form-error" id="minimum_quantity_error"></div>
                                </div>
                            </div>
                            {{-- <div class="col-lg-2 col-sm-6 col-12 update_inventory-section">
                                <div class="form-group">
                                    <label>Opening Quantity</label>
                                    <input type="text" name="quantity" value="{{$product->varaint->quantity ?? ''}}">
                                    <div class="text-danger form-error" id="quantity_error"></div>
                                </div>
                            </div> --}}
                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Purchase Price</label>
                                    <input type="text" name="purchase_price" value="{{$product->varaint->purchase_price ?? ''}}">
                                    <div class="text-danger form-error" id="purchase_price_error"></div>
                                </div>
                            </div>

                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Landing Cost</label>
                                    <input type="text" name="landing_cost" value="{{$product->varaint->landing_cost ?? ''}}">
                                    <div class="text-danger form-error" id="landing_cost_error"></div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>MRP</label>
                                    <input type="text" name="mrp" value="{{$product->varaint->mrp ?? ''}}">
                                    <div class="text-danger form-error" id="mrp_error"></div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Selling Discount</label>
                                    <input type="text" name="discount" value="{{$product->varaint->discount ?? ''}}">
                                    <div class="text-danger form-error" id="discount_error"></div>
                                </div>
                            </div>

                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Selling Price</label>
                                    <input type="text" name="price" value="{{$product->varaint->price ?? ''}}">
                                    <div class="text-danger form-error" id="price_error"></div>
                                </div>
                            </div>

                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Selling Margin</label>
                                    <input type="text" name="selling_margin" value="{{$product->varaint->selling_margin ?? ''}}">
                                    <div class="text-danger form-error" id="selling_margin_error"></div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Retailer Discount</label>
                                    <input type="text" name="retailer_discount" value="{{$product->varaint->retailer_discount ?? ''}}">
                                    <div class="text-danger form-error" id="retailer_discount_error"></div>
                                </div>
                            </div>

                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Retailer Price</label>
                                    <input type="text" name="retailer_price" value="{{$product->varaint->retailer_price ?? ''}}">
                                    <div class="text-danger form-error" id="retailer_price_error"></div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Retailer Margin</label>
                                    <input type="text" name="retailer_margin" value="{{$product->varaint->retailer_margin ?? ''}}">
                                    <div class="text-danger form-error" id="retailer_margin_error"></div>
                                </div>
                            </div>
                            
                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Wholesale Discount</label>
                                    <input type="text" name="wholesale_discount" value="{{$product->varaint->wholesale_discount ?? ''}}">
                                    <div class="text-danger form-error" id="wholesale_discount_error"></div>
                                </div>
                            </div>

                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Wholesale Price</label>
                                    <input type="text" name="wholesale_price" value="{{$product->varaint->wholesale_price ?? ''}}">
                                    <div class="text-danger form-error" id="wholesale_price_error"></div>
                                </div>
                            </div>
                            <div class="col-lg-2 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Wholesale Margin</label>
                                    <input type="text" name="retailer_margin" value="{{$product->varaint->retailer_margin ?? ''}}">
                                    <div class="text-danger form-error" id="wholesale_margin_error"></div>
                                </div>
                            </div>
                </div>
            </div>
            @endif
            <div class="card">
                <div class="card-header">
                    <h4>Ecommerce Details</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12 col-sm-12 col-12">
                            <div class="form-group">
                                <label>Slug</label>
                                <input type="text" name="slug" value="{{$product->slug}}">
                                <div class="text-danger form-error" id="slug_error"></div>
                            </div>
                        </div>
                        <div class="col-lg-12 col-sm-12 col-12">
                            <div class="form-group">
                                <label>Meta Title</label>
                                <input type="text" name="meta_title" value="{{$meta_details['meta_title'] ?? ''}}">
                                <div class="text-danger form-error" id="meta_title_error"></div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Meta Keyword</label>
                                <textarea type="text" name="meta_keywords">{{$meta_details['meta_keywords'] ?? ''}}</textarea>
                                <div class="text-danger form-error" id="meta_keywords_error"></div>
                            </div>
                        </div>
                        
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label>Meta Description</label>
                                <textarea class="form-control" name="meta_description">{{$meta_details['meta_description'] ?? ''}}</textarea>
                                <div class="text-danger form-error" id="meta_description_error"></div>
                            </div>
                        </div>
                         
                        
                     
                       
                      
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <button type="submit" class="btn btn-submit me-2">Submit</button>
                <a href="{{route('admin.product.index')}}" class="btn btn-cancel">Cancel</a>
            </div>
        <!-- /add -->
        </form>
        <!-- /add -->
    </div>
</div>
@endsection