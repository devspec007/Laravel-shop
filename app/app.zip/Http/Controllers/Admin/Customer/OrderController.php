<?php

namespace App\Http\Controllers\Admin\Customer;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;
use PDF;
class OrderController extends Controller
{
    public function index(Request $request)
    {
        $orders = Order::orderBy('created_at', 'desc')->where('order_type', 'order');
        if(isset($request->search) && !empty($request->search)) {
            $orders->where(function($query) use($request){
                $query->where('customer_name', 'like', '%'.$request->search.'%')
                ->orwhere('customer_mobile', 'like', '%'.$request->search.'%');
            });
        }
        if(isset($request->refrence_number) && !empty($request->refrence_number)) {
            $orders->where('order_number', 'like', '%'.$request->refrence_number.'%');
        }

        if(isset($request->start_date) && !empty($request->start_date)) {
            $orders->wheredate('order_date', '>=' ,$request->start_date);
        }
        if(isset($request->end_date) && !empty($request->end_date)) {
            $orders->wheredate('order_date', '<=' ,$request->end_date);
        }
        if(isset($request->payment_status) && !empty($request->payment_status)) {
            $orders->wherein('payment_status',$request->payment_status);
        }
        if(isset($request->payment_type) && !empty($request->payment_type)) {
            $orders->where('payment_type',$request->payment_type);
        }
        if(isset($request->delivery_type) && !empty($request->delivery_type)) {
            $orders->where('delivery_type',$request->delivery_type);
        }
        $orders = $orders->paginate(20);
        return view('admin.orders.index', compact('orders', 'request'));
    }

    public function show($order_id)
    {
        $order = Order::where(['id'=> $order_id])->where('order_type', 'order')->first();
        if($order) {
            $billing_address = [];
            $shipping_address = [];
            if(!empty($order->billing_address)) {
                $billing_address = json_decode($order->billing_address);
            }
            if(!empty($order->shipping_address)) {
                $shipping_address = json_decode($order->shipping_address);
            }
            return view('admin.orders.details', compact('order', 'shipping_address', 'billing_address'));
        }
    }

    public function invoice($order_id)
    {
        $order = Order::where('id',$order_id)->where('order_type', 'order')->first();
        $pdf = PDF::loadView('admin.sales.invoice', ['order' => $order]);
        return $pdf->stream("invoice.pdf", array("Attachment" => false));
    }

}
