<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductSkuOption;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    function __construct()
    {
        $this->middleware('permission:product-list|product-add|product-edit|product-delete', ['only' => ['index','store']]);
        $this->middleware('permission:product-add', ['only' => ['create','store']]);
        $this->middleware('permission:product-edit', ['only' => ['edit','update']]);
        $this->middleware('permission:product-delete', ['only' => ['destroy']]);
    }


    public function getShopProducts()
    {
        $products = Product::with('subcategory', 'brand', 'category', 'varaints', 'varaints.productAttributes', 'primaryImage')->where('status', 'active');

        $products = $products->paginate(100);
        return response(['products' => $products]);
    }

    public function quickView($product_id)
    {
        $product = Product::find($product_id);
        $data = view('frontend.component.product_quick_view', compact('product'))->render();
        return response(['data' => $data]);
    }

    public function product($slug)
    {
        $product = Product::where('slug', $slug)->first();
        $variants = $product->availableVaraints;
        $options = ProductSkuOption::with('attribute')->whereIn('sku_id', array_column(($product->availableVaraints)->toArray(), 'id'))->groupBy('attribute_id')->groupBy('attribute_value')->orderBy('attribute_id')->get();
        
        $varaint_options = [];
        foreach($options as $option) {
            if(isset($varaint_options[$option->attribute->id])) {
                array_push($varaint_options[$option->attribute->id], ['option' => $option->attribute_value, 'lable' => $option->attribute->lable]);
            }
            else {
                $varaint_options[$option->attribute->id] = [];
                array_push($varaint_options[$option->attribute->id], ['option' => $option->attribute_value, 'lable' => $option->attribute->lable]);

            }
        }
        
        print_r(json_encode($varaint_options));
       return view('frontend.view_product', compact('product', 'varaint_options'));
        
    }
}
