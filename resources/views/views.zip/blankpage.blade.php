<?php $page="blankpage";?>
@extends('layout.mainlayout')
@section('content')	
<div class="page-wrapper pagehead">
    <div class="content">
        <div class="page-header">
            <div class="row">
                <div class="col-sm-12">
                    <h3 class="page-title">Blank Page</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{url('index')}}">Dashboard</a></li>
                        <li class="breadcrumb-item active">Blank Page</li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                Contents here
            </div>			
        </div>
    </div>
</div>
@endsection