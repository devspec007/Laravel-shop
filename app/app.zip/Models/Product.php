<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Auth;
class Product extends Model
{
    use HasFactory;
    protected $fillable = ['display_name', 'name', 'sku', 'brand_id','sub_brand_id', 'category_id', 'subcategory_id', 'slug', 'description', 'status', 'created_by', 'product_type', 'expiry_months', 'display_name', 'hsn_code', 'purchase_tax', 'sale_tax', 'is_purchase_tax', 'is_sale_tax'];

    public function user()
    {
        return $this->belongsTo(User::class, 'created_by', 'id');
    }

    public function category()
    {
        return $this->belongsTo(Category::class, 'category_id', 'id');
    }

    public function subcategory()
    {
        return $this->belongsTo(Category::class, 'subcategory_id', 'id');
    }

    public function brand()
    {
        return $this->belongsTo(Brand::class, 'brand_id', 'id');
    }

    public function primaryImage()
    {
        return $this->hasOne(Media::class, 'linkable_id', 'id')->where(['linkable_type'=> 'product', 'is_primary' => 1]);
    }

    public function variantOptions()
    {
       return $this->hasMany(ProductVariantAttribute::class, 'product_id', 'id');
    }

    public function varaints()
    {
        return $this->hasMany(ProductSku::class, 'product_id', 'id');
    }

    public function varaint()
    {
        return $this->hasOne(ProductSku::class, 'product_id', 'id');
    }
    public function availableVaraints()
    {
        return $this->hasMany(ProductSku::class, 'product_id', 'id')->whereHas('inventories')->orderBy('price', 'asc');
    }

    public function inventories()
    {
        return $this->hasMany(ProductInventory::class , 'product_id', 'id')->where('left_quantity', '>', 0);
    }

    public function currentInventories()
    {
        return $this->hasMany(ProductInventory::class , 'product_id', 'id')->where('left_quantity', '>', 0)->where('store_id', Auth::id());
    }

    public function productFullName()
    {
        return $this->name;
       $name = $this->name;
       if( $this->category ) {
        $name .= ' '.$this->category->name;
       }
       if( $this->subcategory ) {
        $name .= ' '.$this->subcategory->name;
       }
       if( $this->brand ) {
        $name .= ' '.$this->brand->name;
       }
       return $name;
    }

    public function attributes()
    {
        return $this->belongsToMany(VariantAttribute::class,ProductVariantAttribute::class,'product_id','variant_id');
        return $this->hasMany(ProductVariantAttribute::class, 'product_id', 'id');
    }

    
}
