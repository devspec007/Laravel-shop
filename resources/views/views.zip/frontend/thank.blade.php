@extends('frontend.layout.layout')
@section('content')
    thank you
@endsection