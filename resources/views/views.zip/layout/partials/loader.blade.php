<div id="global-loader" >
    <div class="whirly-loader"> </div>
</div>