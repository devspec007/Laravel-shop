@foreach ($products as $product)
    @foreach ($product->currentInventories as $inventory)
        
        <div class="col-lg-3 col-sm-6 d-flex ">
            <div class="productset flex-fill" data-product="{{$inventory->id}}"  data-type="pos_order">
                <input type="checkbox"  class="pos-brand-category-checkbox">
                
                <div class="productsetimg">
                    <img src="{{ $inventory->product && $inventory->product->primaryImage ? asset('uploads/products/'.$inventory->product->primaryImage->image) : URL::asset('/assets/img/product/product1.jpg')}}" alt="img">
                    <h6>Qty: {{$inventory->left_quantity}}</h6>
                   
                </div>
                <div class="productsetcontent">
                    <h5>{{$inventory->product->name}}</h5>
                    <h4>{{$inventory->product->category->name}} {{$inventory->product->subcategory->name}} {{$inventory->product->brand->name}}</h4>
                    <h5>SKU : {{$inventory->sku->sku}}</h5>
                    <h5>
                        @foreach ($inventory->sku->productAttributes as $productAttributes)
                        {{$productAttributes->attribute->lable .":".$productAttributes->attribute_value}} /
                    @endforeach
                    </h5>
                    <h6>Purchase Price : ₹ {{$inventory->unit_price}}</h6>
                    <h6>Sales Price : ₹ {{$inventory->sku->regular_price}}</h6>
                    <div >
                        <button class="btn btn-sm btn-primary">Add To Cart</button>
                    </div>
                </div>
            </div>
        </div>
    @endforeach
@endforeach