<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Brand;
use App\Models\CustomerAddress;
use App\Models\Place;
use App\Models\User;
use App\Models\VariantAttribute;
use Attribute;
use Illuminate\Http\Request;
use Auth;
class FrontendController extends Controller
{
    public function home()
    {
       return view('frontend.home');
    }

    public function shop(Request $request)
    {
        $filters = VariantAttribute::where('status', 'active')->get();
        $brands = Brand::where('status', 'active')->get();
        return view('frontend.shop', compact('filters', 'brands'));
    }

    public function about()
    {
        return view('frontend.about');
    }

    public function cart()
    {
        return view('frontend.cart');
    }

    public function checkout()
    {
        $addresses = [];
        if(Auth::check()) {
            $addresses = CustomerAddress::get();
        }
        $states = Place::where('type', 'state')->get();
        $stores = User::where('type', 'store')->where('status', 'active')->get();
    
        return view('frontend.checkout', compact('addresses', 'states', 'stores'));
    }

    public function thanks()
    {
        return view('frontend.thank');
    }

    public function paymentFailed()
    {
        return view('frontend.payment_failed');
    }

}
